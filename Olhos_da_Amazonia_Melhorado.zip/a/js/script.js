const menuToggle=document.querySelector(".menu-toggle");
const navbar=document.querySelector(".navbar");
menuToggle?.addEventListener("click",()=>{const open=navbar.classList.toggle("open");menuToggle.setAttribute("aria-expanded",open);});
document.querySelectorAll(".navbar a").forEach(a=>a.addEventListener("click",()=>navbar.classList.remove("open")));

const lightbox=document.getElementById("lightbox");
const lightboxImg=document.getElementById("lightbox-img");
document.querySelectorAll(".gallery-item").forEach(item=>item.addEventListener("click",()=>{
  lightboxImg.src=item.dataset.full; lightboxImg.alt=item.querySelector("img").alt;
  lightbox.classList.add("open"); lightbox.setAttribute("aria-hidden","false");
}));
document.querySelector(".close-lightbox").addEventListener("click",closeLightbox);
lightbox.addEventListener("click",e=>{if(e.target===lightbox)closeLightbox()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeLightbox()});
function closeLightbox(){lightbox.classList.remove("open");lightbox.setAttribute("aria-hidden","true");lightboxImg.src="";}

document.getElementById("contact-form").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("form-status").textContent="Mensagem preparada! Para receber mensagens de verdade, conecte este formulário a um serviço de envio.";
  e.target.reset();
});
